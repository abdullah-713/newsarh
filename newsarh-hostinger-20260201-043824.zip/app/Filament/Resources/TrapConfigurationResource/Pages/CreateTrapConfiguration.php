<?php

namespace App\Filament\Resources\TrapConfigurationResource\Pages;

use App\Filament\Resources\TrapConfigurationResource;
use Filament\Resources\Pages\CreateRecord;

class CreateTrapConfiguration extends CreateRecord
{
    protected static string $resource = TrapConfigurationResource::class;
}
