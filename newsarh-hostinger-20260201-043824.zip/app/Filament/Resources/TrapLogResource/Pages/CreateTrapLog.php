<?php

namespace App\Filament\Resources\TrapLogResource\Pages;

use App\Filament\Resources\TrapLogResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTrapLog extends CreateRecord
{
    protected static string $resource = TrapLogResource::class;
}
