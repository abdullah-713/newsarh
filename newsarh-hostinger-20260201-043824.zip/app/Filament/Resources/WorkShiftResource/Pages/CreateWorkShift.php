<?php

namespace App\Filament\Resources\WorkShiftResource\Pages;

use App\Filament\Resources\WorkShiftResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWorkShift extends CreateRecord
{
    protected static string $resource = WorkShiftResource::class;
}
